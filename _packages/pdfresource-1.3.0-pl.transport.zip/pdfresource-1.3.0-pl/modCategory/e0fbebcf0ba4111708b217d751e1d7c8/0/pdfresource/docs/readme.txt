PDFresource
===========

PDFresource is a MODX Revolution extra that converts resources to PDF files using mPDF (http://www.mpdf1.com/).

Usage
-----
Install via package manager, assign the needed template variables to the resource that should be converted. Change the default PDF options in the system settings or on resource base in a template variable.

Documentation
-------------
http://jako.github.io/PDFresource/

GitHub Repository
-----------------
https://github.com/Jako/PDFresource
