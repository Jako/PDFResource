<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => 'PDFResource
===========

PDFResource is a MODX Revolution extra that converts resources to PDF files using mPDF (https://mpdf.github.io/).

Usage
-----
Install via package manager, assign the needed template variables to the resource that should be converted. Change the default PDF options in the system settings or on resource base in a template variable.

Documentation
-------------
http://jako.github.io/PDFResource/

GitHub Repository
-----------------
https://github.com/Jako/PDFResource
',
    'changelog' => 'Changelog for PDFResource
=========================

- 1.5.6
    - Bugfix for creating folders recursive
- 1.5.5
    - Bugfix for PHP version specific issues
- 1.5.4
    - Change mPDF documentation links to https://mpdf.github.io/
- 1.5.3
    - Update mPDF to 1.6.1
- 1.5.2
    - Bugfix for wrong PDF margin header
- 1.5.1
    - Bugfix for resource based PDF options
- 1.5.0
    - Set all mPDF options by calling mPDF class methods with callbacks
    - Improved error logging

- 1.4.0
    - PDF password protection

- 1.3.0
    - Create PDF files on the fly by assigning and checking the template
      variable live_pdf

- 1.2.3
    - Bugfix for create_pdf template variable is assigned to the template
- 1.2.2
    - Load mPDF/modPDF class only if needed for less memory usage
    - Added pdfresource.generateOnPrerender system setting
- 1.2.1
    - Check if the create_pdf template variable is assigned to the template
    - Modified alias path generation
- 1.2.0
    - Add custom fonts by pdfresource.customFonts system setting

- 1.1.0
    - Create not existing PDF files during OnWebPagePrerender

- 1.0.0
    - Initial Release for MODX Revolution
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fe657b4dc0ed804ad49777d169b1eaa0',
      'native_key' => 'pdfresource',
      'filename' => 'modNamespace/ff1fd2ec59200aa48722e58cc17fa47f.vehicle',
      'namespace' => 'pdfresource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55b14ec30357fb12d877c9f4b82f3ed4',
      'native_key' => 'pdfresource.mode',
      'filename' => 'modSystemSetting/916704ef8e7806df6422e23f0278d373.vehicle',
      'namespace' => 'pdfresource',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '588a3d02454c4c204dfcda3296acb7cf',
      'native_key' => 'pdfresource.format',
      'filename' => 'modSystemSetting/2e44aa838927acd211255b47224d097e.vehicle',
      'namespace' => 'pdfresource',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3331416053f8d2f94a7b17db203e15aa',
      'native_key' => 'pdfresource.defaultFontSize',
      'filename' => 'modSystemSetting/9c6e58a1785c20e98defd28696c91045.vehicle',
      'namespace' => 'pdfresource',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3c03267aef984816db24bcd771ed4ab',
      'native_key' => 'pdfresource.defaultFont',
      'filename' => 'modSystemSetting/af0d8ccfb582872160eda7d1149d64b3.vehicle',
      'namespace' => 'pdfresource',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468bd3a641f864cc111e7bdc1c036765',
      'native_key' => 'pdfresource.mgl',
      'filename' => 'modSystemSetting/eccab2ab2bf77c44d55dc7fbac42d1c9.vehicle',
      'namespace' => 'pdfresource',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfbcf29f5ea7a0923a3a2dc70a58a542',
      'native_key' => 'pdfresource.mgr',
      'filename' => 'modSystemSetting/04e16d3ac81b3b2e253114512729bf7b.vehicle',
      'namespace' => 'pdfresource',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c51863b787fc1a54bc8c0a8060dee5d',
      'native_key' => 'pdfresource.mgt',
      'filename' => 'modSystemSetting/1c7474488d2515c93482b34cd265caa8.vehicle',
      'namespace' => 'pdfresource',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29cf473f0c47647f12e8215d95b0cad1',
      'native_key' => 'pdfresource.mgb',
      'filename' => 'modSystemSetting/cdd418bd1a38b9c368299197eb37c95c.vehicle',
      'namespace' => 'pdfresource',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edf39981ab7d33c9db40f9c365f6ef65',
      'native_key' => 'pdfresource.mgh',
      'filename' => 'modSystemSetting/75a1e6b0d46113fe2594af0de5b41717.vehicle',
      'namespace' => 'pdfresource',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9af259632d26a8c68d5228b2537fe3d5',
      'native_key' => 'pdfresource.mgf',
      'filename' => 'modSystemSetting/50e19a87e4d41a791a3e3f549b7f4abc.vehicle',
      'namespace' => 'pdfresource',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3470646cce3401a939ff8999428aa4da',
      'native_key' => 'pdfresource.orientation',
      'filename' => 'modSystemSetting/ab8b9744742e1254b0b54a67f69021e6.vehicle',
      'namespace' => 'pdfresource',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9693e8f24d93408427fd2665d80a90a2',
      'native_key' => 'pdfresource.customFonts',
      'filename' => 'modSystemSetting/da7627a81a6ed7ffffd24bbd4fd6f5f8.vehicle',
      'namespace' => 'pdfresource',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5edafad4a07d0ec150a0c17250ea5e7a',
      'native_key' => 'pdfresource.generateOnPrerender',
      'filename' => 'modSystemSetting/9330ab5db26dbe70ee7b80758dbc092a.vehicle',
      'namespace' => 'pdfresource',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b27d76a0fde692fc8a783c595a5fa26',
      'native_key' => 'pdfresource.permissions',
      'filename' => 'modSystemSetting/4bf2d81dbceffc5add127992cb9c9137.vehicle',
      'namespace' => 'pdfresource',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bb246bd5b43a91849ae1c1f52d4f0d9',
      'native_key' => 'pdfresource.userPassword',
      'filename' => 'modSystemSetting/2211e8f6cfab7480fbaa73f55bc430fe.vehicle',
      'namespace' => 'pdfresource',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6e78dd62fd68ddeccff54b4914bb9df',
      'native_key' => 'pdfresource.ownerPassword',
      'filename' => 'modSystemSetting/fb25688ee2de5a50cb74f08dc8c54371.vehicle',
      'namespace' => 'pdfresource',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '023a24cf08cbc4b0fc60e98beebad66a',
      'native_key' => 'pdfresource.mPDFMethods',
      'filename' => 'modSystemSetting/6b3c81c0b2e2d1a6ca30c3bc85b425b4.vehicle',
      'namespace' => 'pdfresource',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fc02bff56557d24e589f4278432e30f',
      'native_key' => 'pdfresource.pdfTv',
      'filename' => 'modSystemSetting/717cdc508f6dc8fbdd933d2478c89242.vehicle',
      'namespace' => 'pdfresource',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '290360d7f5c10e3c7dcdfaefd48231b9',
      'native_key' => 'pdfresource.pdfTvLive',
      'filename' => 'modSystemSetting/3c7f10a0f4d90deaf88a12ba1af34245.vehicle',
      'namespace' => 'pdfresource',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edfe72101fca0e70fde59055c4a09fb9',
      'native_key' => 'pdfresource.pdfTvOptions',
      'filename' => 'modSystemSetting/7dfe36b088484b42c0bcba5684d8f538.vehicle',
      'namespace' => 'pdfresource',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db46e0920319897cf5539c51422c2197',
      'native_key' => 'pdfresource.pdfTpl',
      'filename' => 'modSystemSetting/adb597b93d55762818c9e9640ff29c2f.vehicle',
      'namespace' => 'pdfresource',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02eaac15155a1bb003fb49bdedf06c55',
      'native_key' => 'pdfresource.cssTpl',
      'filename' => 'modSystemSetting/eb158de4f020a83ca80a9214b826ebcf.vehicle',
      'namespace' => 'pdfresource',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c46374616c130e0e2b5e2e34a1485c24',
      'native_key' => 'pdfresource.processTVs',
      'filename' => 'modSystemSetting/31bd2df2c5e51325a7b37440396237c4.vehicle',
      'namespace' => 'pdfresource',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '367a5016e922e28b56a3b19dec4c2d5a',
      'native_key' => 'pdfresource.tvPrefix',
      'filename' => 'modSystemSetting/e6cff5ae344ea31c40132e454f9b30f5.vehicle',
      'namespace' => 'pdfresource',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4f8c6d59d0a156d288395fd398d2de0e',
      'native_key' => NULL,
      'filename' => 'modCategory/68ae85a34041584b332ef2740d6c7b9c.vehicle',
      'namespace' => 'pdfresource',
    ),
  ),
);