PDFresource
===========

PDFresource is a MODX Revolution extra that converts resources to PDF files on saving the resource using mPDF (http://www.mpdf1.com/).

Usage
-----
Install via package manager and change the default options in the system settings.

Documentation
-------------
http://jako.github.io/PDFresource/

GitHub Repository
-----------------
https://github.com/Jako/PDFresource
