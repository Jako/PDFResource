<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'pdfresource-1.5.8-pl/setup-options.php',
    'requires' => 
    array (
      'modx' => '>=2.4',
      'php' => '>=5.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f27ff540bc9b40da4d768857e03f496f',
      'native_key' => 'pdfresource',
      'filename' => 'modNamespace/f7a25fbdb8312188f8db2bd802456797.vehicle',
      'namespace' => 'pdfresource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '901e736e72e35900a54618847e861f76',
      'native_key' => 'pdfresource.mode',
      'filename' => 'modSystemSetting/ed07fb9826581d86626150ce127e7d3a.vehicle',
      'namespace' => 'pdfresource',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '568c6a01b4b31195c7f835130d19b267',
      'native_key' => 'pdfresource.format',
      'filename' => 'modSystemSetting/b80f339fcc612aec2c7808bb527d5d2b.vehicle',
      'namespace' => 'pdfresource',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd62ef73ff7003fdd57d1ce5dd83a44da',
      'native_key' => 'pdfresource.defaultFontSize',
      'filename' => 'modSystemSetting/17070934b16f9dd204875c61a2e1c488.vehicle',
      'namespace' => 'pdfresource',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5e0aae3f9da10fdef6548e30723f2fa',
      'native_key' => 'pdfresource.defaultFont',
      'filename' => 'modSystemSetting/b6adabfc912ce263d1c10c034501fdd2.vehicle',
      'namespace' => 'pdfresource',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cb8adf73470bc2d00ce71082b596589',
      'native_key' => 'pdfresource.mgl',
      'filename' => 'modSystemSetting/830ca097f7217f2ad7aec806a20eed75.vehicle',
      'namespace' => 'pdfresource',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be9147d398c311e083ed737394abd2ee',
      'native_key' => 'pdfresource.mgr',
      'filename' => 'modSystemSetting/aabd0f012c6dd7fec5c6ec2e6cfd5879.vehicle',
      'namespace' => 'pdfresource',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4413e1cccf4522ffa395544796bee55b',
      'native_key' => 'pdfresource.mgt',
      'filename' => 'modSystemSetting/849da02602a917b22540fdafcd9580f4.vehicle',
      'namespace' => 'pdfresource',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6085d593f188a218e40a81d3f7ce2a',
      'native_key' => 'pdfresource.mgb',
      'filename' => 'modSystemSetting/9b893ce66b1ab00147950923d29d5179.vehicle',
      'namespace' => 'pdfresource',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93fb30f6c2c453098d41553eb3227c50',
      'native_key' => 'pdfresource.mgh',
      'filename' => 'modSystemSetting/845786d92b54cb09e9ec216b8d8afc68.vehicle',
      'namespace' => 'pdfresource',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48d58d981f88aab7362e48720c833d27',
      'native_key' => 'pdfresource.mgf',
      'filename' => 'modSystemSetting/4f06fd7b144790f22898196354ba4ff3.vehicle',
      'namespace' => 'pdfresource',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '550e4bef404d5834f9e2f5b8ea04bf77',
      'native_key' => 'pdfresource.orientation',
      'filename' => 'modSystemSetting/812d358c4a8458a32dd4d76f2c0d273d.vehicle',
      'namespace' => 'pdfresource',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa7f7776f905e4e1a3aa441209aef79e',
      'native_key' => 'pdfresource.customFonts',
      'filename' => 'modSystemSetting/730541433c768d303f0e53c128b33960.vehicle',
      'namespace' => 'pdfresource',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08c251188a4de157de9fd5f77f21c57d',
      'native_key' => 'pdfresource.generateOnPrerender',
      'filename' => 'modSystemSetting/3ee7f25a463b3b132e46aa08d4e43a27.vehicle',
      'namespace' => 'pdfresource',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae3314d7bccf6687d3bf0bb812a8ffee',
      'native_key' => 'pdfresource.permissions',
      'filename' => 'modSystemSetting/8dd580288a25cb32ac76356240207751.vehicle',
      'namespace' => 'pdfresource',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b41cafc1b226480943d135f132e3e1a',
      'native_key' => 'pdfresource.userPassword',
      'filename' => 'modSystemSetting/fd0549a25261e2a28c16f4b62c4628ed.vehicle',
      'namespace' => 'pdfresource',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51965794c57cdd5223b7e0debfaf61f',
      'native_key' => 'pdfresource.ownerPassword',
      'filename' => 'modSystemSetting/d846b259e37058ee3b8b48beb6a6508d.vehicle',
      'namespace' => 'pdfresource',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40b84f8dd821f0d438559b25e55a4710',
      'native_key' => 'pdfresource.mPDFMethods',
      'filename' => 'modSystemSetting/1cffb42636d6bdff4bb4019a72b66c27.vehicle',
      'namespace' => 'pdfresource',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e2fc47c9d8d7f071e9d72da145ea91c',
      'native_key' => 'pdfresource.pdfTv',
      'filename' => 'modSystemSetting/2db8a6d28d9e8cfa98da012a78d6319a.vehicle',
      'namespace' => 'pdfresource',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18ffa0c4e23b89671ae22abffa7417b7',
      'native_key' => 'pdfresource.pdfTvLive',
      'filename' => 'modSystemSetting/999076b73dd4ca8ee554bd11af691939.vehicle',
      'namespace' => 'pdfresource',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd558b6faf4fae71e2dd5b556b18f71c8',
      'native_key' => 'pdfresource.pdfTvOptions',
      'filename' => 'modSystemSetting/935f53e331717ed76213690988b3e24d.vehicle',
      'namespace' => 'pdfresource',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b529131021393d00dea8a5621e5c727',
      'native_key' => 'pdfresource.pdfTpl',
      'filename' => 'modSystemSetting/15cc114003a344c852fd3919dc46ec40.vehicle',
      'namespace' => 'pdfresource',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8263ceaf8747270cf633d504f312685e',
      'native_key' => 'pdfresource.cssTpl',
      'filename' => 'modSystemSetting/7e4cdcc79920f1b4bcfc4d9cb6cedd09.vehicle',
      'namespace' => 'pdfresource',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '064a20590c43a92e2c1b8ee3911c4a29',
      'native_key' => 'pdfresource.processTVs',
      'filename' => 'modSystemSetting/3441ead0d97d7d040a77ed12ff6924d4.vehicle',
      'namespace' => 'pdfresource',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e338aa6b937fc7dae65523a79634cb1',
      'native_key' => 'pdfresource.tvPrefix',
      'filename' => 'modSystemSetting/96c328fc941ae2dfe4d8d3cc19b14c30.vehicle',
      'namespace' => 'pdfresource',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '889400f8d7b21544306fe06ea6561025',
      'native_key' => NULL,
      'filename' => 'modCategory/9fe1adf21f98268cf40ca47a07cb9985.vehicle',
      'namespace' => 'pdfresource',
    ),
  ),
);