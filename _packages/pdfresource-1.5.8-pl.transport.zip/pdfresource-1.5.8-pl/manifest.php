<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'pdfresource-1.5.8-pl/setup-options.php',
    'requires' => 
    array (
      'modx' => '>=2.4',
      'php' => '>=5.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f0b4504fe55412e734ecab146454e976',
      'native_key' => 'pdfresource',
      'filename' => 'modNamespace/ede622339066572b363826af17ea40a8.vehicle',
      'namespace' => 'pdfresource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c41ccde5752d11d268a8450fb8a2b4b',
      'native_key' => 'pdfresource.mode',
      'filename' => 'modSystemSetting/98be5cd112c73c1a64556dfe80c20b9e.vehicle',
      'namespace' => 'pdfresource',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57e942e7329d47e1964f87451b9415ae',
      'native_key' => 'pdfresource.format',
      'filename' => 'modSystemSetting/861b4b791dcf795cdbf92c2b4cb88bf2.vehicle',
      'namespace' => 'pdfresource',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2221c83e19560610d2681fc52a7c5853',
      'native_key' => 'pdfresource.defaultFontSize',
      'filename' => 'modSystemSetting/4db43e5e2e4c7e592adb389d26378c43.vehicle',
      'namespace' => 'pdfresource',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '975de5b47543f5402be81e8d720ca454',
      'native_key' => 'pdfresource.defaultFont',
      'filename' => 'modSystemSetting/24b082b01849282f08a8bae51351627b.vehicle',
      'namespace' => 'pdfresource',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f82757e31dcd1cbcf59b9285fb1f8029',
      'native_key' => 'pdfresource.mgl',
      'filename' => 'modSystemSetting/10bedb50f1bcf6dd8a6e602b8e6cb5d8.vehicle',
      'namespace' => 'pdfresource',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da216078160a994c86cf9ce00297ae30',
      'native_key' => 'pdfresource.mgr',
      'filename' => 'modSystemSetting/136c28f7b4969ddee31904db7e22f83d.vehicle',
      'namespace' => 'pdfresource',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76c8467d6d5a13016e821e8073ba6754',
      'native_key' => 'pdfresource.mgt',
      'filename' => 'modSystemSetting/2cc04fe6ffa46079a0c430cb71701440.vehicle',
      'namespace' => 'pdfresource',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5804f29263e5c6825949738b33d6e39',
      'native_key' => 'pdfresource.mgb',
      'filename' => 'modSystemSetting/eadcaed97e1ca68ed679a58ada2614ea.vehicle',
      'namespace' => 'pdfresource',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58647a9569859122c599d780425c1879',
      'native_key' => 'pdfresource.mgh',
      'filename' => 'modSystemSetting/4c49d5c8c034818301a1c5deae9e8501.vehicle',
      'namespace' => 'pdfresource',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1e2c7be5a8818877ba715838233fd8f',
      'native_key' => 'pdfresource.mgf',
      'filename' => 'modSystemSetting/c316162b890d4d4d1d500a5668cadb53.vehicle',
      'namespace' => 'pdfresource',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5a73efd84b24695fe12c0f4cf5fe73',
      'native_key' => 'pdfresource.orientation',
      'filename' => 'modSystemSetting/b9ff4c17d156b446f5812ef1d99dc680.vehicle',
      'namespace' => 'pdfresource',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7780e9d3a713e0edf187c1582c239f4f',
      'native_key' => 'pdfresource.customFonts',
      'filename' => 'modSystemSetting/475d3c2aad4d01cd7965ef129487b883.vehicle',
      'namespace' => 'pdfresource',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa9c441f0a8a162caf4afb0ed668584a',
      'native_key' => 'pdfresource.generateOnPrerender',
      'filename' => 'modSystemSetting/84b19b1e902f7a7392b867b8e42504c7.vehicle',
      'namespace' => 'pdfresource',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed6dd0f23953361f14f003d7b72d4515',
      'native_key' => 'pdfresource.permissions',
      'filename' => 'modSystemSetting/ec327d8a63b49b03055b411895f650f3.vehicle',
      'namespace' => 'pdfresource',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e67ead28b4d76eebd651694cf3ffc942',
      'native_key' => 'pdfresource.userPassword',
      'filename' => 'modSystemSetting/08aeda04b39f4fe211faba6a21753642.vehicle',
      'namespace' => 'pdfresource',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '106d1994dccac396a2306b57560b1c98',
      'native_key' => 'pdfresource.ownerPassword',
      'filename' => 'modSystemSetting/d8a7ec25a092f188d948eec349eb6306.vehicle',
      'namespace' => 'pdfresource',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09e732397e0b36baaa31cbe81500ffaf',
      'native_key' => 'pdfresource.mPDFMethods',
      'filename' => 'modSystemSetting/8d0921a285a6f1c073bdc55c4179142f.vehicle',
      'namespace' => 'pdfresource',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b269f7ebd229325bc1b772f0e28e51d',
      'native_key' => 'pdfresource.pdfTv',
      'filename' => 'modSystemSetting/9e4effb3eecbbcba61b6968e02a75e23.vehicle',
      'namespace' => 'pdfresource',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1ee3cf92392f8323c5a130e39d0d59c',
      'native_key' => 'pdfresource.pdfTvLive',
      'filename' => 'modSystemSetting/8f0b588df013996dbaabb1a8e736d1cd.vehicle',
      'namespace' => 'pdfresource',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9025fc2c2631a5ed3eb2054374459b01',
      'native_key' => 'pdfresource.pdfTvOptions',
      'filename' => 'modSystemSetting/fd661a22721dd1d785ee50dd76f91225.vehicle',
      'namespace' => 'pdfresource',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6c02e612dec90bb92a206496c512c28',
      'native_key' => 'pdfresource.pdfTpl',
      'filename' => 'modSystemSetting/999d5614820b7e7830c4282144bf1739.vehicle',
      'namespace' => 'pdfresource',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1be54879e1a60647a9cc90aadbc376e7',
      'native_key' => 'pdfresource.cssTpl',
      'filename' => 'modSystemSetting/26977ed0e4958def863f05dc01469deb.vehicle',
      'namespace' => 'pdfresource',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '989f9594758d6f5c66ea61c31753f662',
      'native_key' => 'pdfresource.processTVs',
      'filename' => 'modSystemSetting/de8291e073d09930be4c3f53b21dbb54.vehicle',
      'namespace' => 'pdfresource',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '620f1f5cdb85e2ab44556419a95e852d',
      'native_key' => 'pdfresource.tvPrefix',
      'filename' => 'modSystemSetting/b00da9d53db01e0deecba7912d4e65e5.vehicle',
      'namespace' => 'pdfresource',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dce803239a341c29325913b68f4c2798',
      'native_key' => NULL,
      'filename' => 'modCategory/a38620d6ba7dbf43738a6bab123e8621.vehicle',
      'namespace' => 'pdfresource',
    ),
  ),
);