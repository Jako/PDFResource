<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# PDFResource

Convert MODX resources to PDF files using mPDF (https://mpdf.github.io/).

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

- Create a static PDF file of a MODX resource with mPDF during saving or on viewing the resource.
- Create a PDF file of a MODX resource on the fly with mPDF.
- The options for the generated PDF could be set in MODX system settings and on resource base.

## Installation

MODX Package Management

## Documentation

https://jako.github.io/PDFResource/

## GitHub Repository

https://github.com/Jako/PDFResource

## License

The project is licensed under the [GPLv2 license](https://github.com/Jako/PDFResource/blob/master/core/components/pdfresource/docs/license.md).

## Third party licenses

This extra includes third party software, for which we are thankful.

* mpdf/mpdf@v8.3.1 [GPL-2.0-only]
* mpdf/psr-http-message-shim@v2.0.1 [MIT]
* mpdf/psr-log-aware-trait@v2.0.0 [MIT]
* myclabs/deep-copy@1.13.4 [MIT]
* paragonie/random_compat@v9.99.100 [MIT]
* psr/http-message@2.0 [MIT]
* psr/log@1.1.4 [MIT]
* setasign/fpdi@v2.6.9 [MIT]',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2026-11-04

### Added

- Add `headerTpl` and `footerTpl` options to set the HTML header and footer of the PDF pages with a template chunk
- Increase the top/bottom margin automatically, if the HTML header/footer needs more space
- Log a warning, if a template chunk could not be loaded

### Changed

- Load the PDF stylesheet before the mPDF methods set by `mPDFMethods` are called
- Update Composer dependencies

## [2.0.4] - 2026-05-20

### Security

- Update Setasign FPDI dependency to fix a security issue

## [2.0.3] - 2025-08-08

### Security

- Update Setasign FPDI dependency to fix a security issue

## [2.0.2] - 2025-02-04

### Changed

- The output filter `PDFResourceLink` returns `-` if the file does not exist

## [2.0.1] - 2022-03-28

### Fixed

- Fix removing the container suffix, when it is not a slash [#38]

## [2.0.0] - 2022-03-28

### Added

- Add pdfresource.customFontsFolder system setting for custom fonts folder
- Add empty pdfresource.author system setting to make manual creation unnecessary
- Add empty pdfresource.creator system setting to make manual creation unnecessary

### Changed

- Install the Composer dependencies directly on the server (semantic major version change because of the custom fonts location)

### Fixed

- Bugfix for default font is always \'dejavusanscondensed\' when using custom fonts [#15]

## [1.6.0] - 2022-01-27

### Added

- Debug output of the html/css before it is handled by mPDF

### Changed

- Code refactoring
- Full MODX 3 compatibility
- Update mPDF to 8.0.17

### Fixed

- Prevent an error, when $modx->resource is not set

## [1.5.10] - 2019-10-20

### Fixed

- Bugfix for saving the PDF with an empty parent resource path

## [1.5.9] - 2019-09-20

### Fixed

- Bugfix for creating the parent alias with a not default container_suffix system setting

## [1.5.8] - 2019-06-07

### Changed

- Update mPDF to 6.1.4

## [1.5.7] - 2017-12-05

### Changed

- GPM options for empty temporary vendor folders

### Fixed

- Bugfix for creating temporary vendor folders
- Bugfix for allowed memory size exhausted

## [1.5.6] - 2017-09-18

### Fixed

- Bugfix for creating folders recursive

## [1.5.5] - 2016-10-14

### Fixed

- Bugfix for PHP version specific issues

## [1.5.4] - 2016-08-15

### Changed

- Change mPDF documentation links to https://mpdf.github.io/

## [1.5.3] - 2016-08-15

### Changed

- Update mPDF to 1.6.1

## [1.5.2] - 2016-04-16

### Fixed

- Bugfix for wrong PDF margin header

## [1.5.1] - 2016-03-15

### Fixed

- Bugfix for resource based PDF options

## [1.5.0] - 2015-11-27

### Added

- Set all mPDF options by calling mPDF class methods with callbacks

### Changed

- Improved error logging

## [1.4.0] - 2015-11-07

### Added

- PDF password protection

## [1.3.0] - 2015-11-05

### Added

- Create PDF files on the fly by assigning and checking the template variable live_pdf

## [1.2.3] - 2015-11-04

### Fixed

- Bugfix for create_pdf template variable is assigned to the template

## [1.2.2] - 2015-11-04

### Added

- pdfresource.generateOnPrerender system setting

### Changed

- Load mPDF/modPDF class only if needed for less memory usage

## [1.2.1] - 2015-11-04

### Added

- Check if the create_pdf template variable is assigned to the template

### Changed

- Modified alias path generation

## [1.2.0] - 2015-11-01

### Added

- Add custom fonts by pdfresource.customFonts system setting

## [1.1.0] - 2015-10-28

### Added

- Create not existing PDF files during OnWebPagePrerender
- Initial release for MODX Revolution
',
    'setup-options' => 'pdfresource-2.1.0-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0476003bbe77e3f215a3faecda8648a3',
      'native_key' => 'pdfresource',
      'filename' => 'modNamespace/c99d80e920179a3c80f1673b0b1a233e.vehicle',
      'namespace' => 'pdfresource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6465773a75526b5560e57cf62a265592',
      'native_key' => 'pdfresource.debug',
      'filename' => 'modSystemSetting/6b677cd00b4a5a3c8a41d4d04571e832.vehicle',
      'namespace' => 'pdfresource',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c54bd51c34358d3f57736af3a2f2dcb9',
      'native_key' => 'pdfresource.mode',
      'filename' => 'modSystemSetting/6c09073d416d061a93428f44edf91f76.vehicle',
      'namespace' => 'pdfresource',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ad1cd02550d8a93d0912fc9be071e1',
      'native_key' => 'pdfresource.format',
      'filename' => 'modSystemSetting/867fa66c33efe199214519b488a484b2.vehicle',
      'namespace' => 'pdfresource',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e1af2ebd7ce041a95a8e4363dbac608',
      'native_key' => 'pdfresource.defaultFontSize',
      'filename' => 'modSystemSetting/6f4d4c82e46a0cd9509fd60f20d8e187.vehicle',
      'namespace' => 'pdfresource',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '812c9554e28229cc2e1e4baf2d2841a2',
      'native_key' => 'pdfresource.defaultFont',
      'filename' => 'modSystemSetting/964ca5ecccddd92ef9ce537cd334a83a.vehicle',
      'namespace' => 'pdfresource',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e314ba1c8d72cab7af31d69c3dc6bb2',
      'native_key' => 'pdfresource.mgl',
      'filename' => 'modSystemSetting/c5d2497578d9e76d54e67d6c3d28dca2.vehicle',
      'namespace' => 'pdfresource',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5630e1d9971ae4c88e14ba966e595756',
      'native_key' => 'pdfresource.mgr',
      'filename' => 'modSystemSetting/99e27e3522b1f7420bb81f57ae3735bd.vehicle',
      'namespace' => 'pdfresource',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dea3cd3b1937cde54b4afa26ddd3b20',
      'native_key' => 'pdfresource.mgt',
      'filename' => 'modSystemSetting/a0cd70d4aa36571ee875a5d16d02c1fe.vehicle',
      'namespace' => 'pdfresource',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '064e0a2322d1613ba2d853319503d6d3',
      'native_key' => 'pdfresource.mgb',
      'filename' => 'modSystemSetting/f90e05fcebd95c83dc63bc2746af7e22.vehicle',
      'namespace' => 'pdfresource',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7db3cd07e49d08397c33192274e5c571',
      'native_key' => 'pdfresource.mgh',
      'filename' => 'modSystemSetting/c27771095ffb424212a366e42c24e673.vehicle',
      'namespace' => 'pdfresource',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1587d00104ff9d174a864d850dd0d434',
      'native_key' => 'pdfresource.mgf',
      'filename' => 'modSystemSetting/27e174f99140c4d5626e5997ab007ff8.vehicle',
      'namespace' => 'pdfresource',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6da79febcf2fbe1de3bb7abb3e69c73b',
      'native_key' => 'pdfresource.orientation',
      'filename' => 'modSystemSetting/1313095ca9059a0751d015c6488f9201.vehicle',
      'namespace' => 'pdfresource',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd312b915f4c5097602edc6124f276a40',
      'native_key' => 'pdfresource.customFonts',
      'filename' => 'modSystemSetting/59e15d141d428576e70297c2ccc5cc7b.vehicle',
      'namespace' => 'pdfresource',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31ee93e9d724ac45b3b0923f2609855c',
      'native_key' => 'pdfresource.customFontsFolder',
      'filename' => 'modSystemSetting/23d60581a99a42413c376b7cb5931b73.vehicle',
      'namespace' => 'pdfresource',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '924aa40fb7ffb7b961e1e71fa2c0bec9',
      'native_key' => 'pdfresource.generateOnPrerender',
      'filename' => 'modSystemSetting/4ec9e1207596c104bdb5acdc1e2c4342.vehicle',
      'namespace' => 'pdfresource',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '187b321b7c8f83cf0a18c9c8832bc3b7',
      'native_key' => 'pdfresource.permissions',
      'filename' => 'modSystemSetting/18880c2b0efabb1a200ec58d38bf1cb3.vehicle',
      'namespace' => 'pdfresource',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23d798c31593d96ce48d978e5a504695',
      'native_key' => 'pdfresource.userPassword',
      'filename' => 'modSystemSetting/dd6c636b2378ef2768ebdd970b18e912.vehicle',
      'namespace' => 'pdfresource',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55c86f34b88b885cfd58b285fa3e18e7',
      'native_key' => 'pdfresource.ownerPassword',
      'filename' => 'modSystemSetting/5a0de01f9f26e7e97fab016b83b16443.vehicle',
      'namespace' => 'pdfresource',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a83fd9ba96c7d07b2f6656806ab8e0b',
      'native_key' => 'pdfresource.mPDFMethods',
      'filename' => 'modSystemSetting/7daf5305e6c4e1d7185346c648ae9f0a.vehicle',
      'namespace' => 'pdfresource',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f594e14d0cc6c9cb000f051503e1388d',
      'native_key' => 'pdfresource.author',
      'filename' => 'modSystemSetting/cda2afe14bb6bb0870123638f828ab92.vehicle',
      'namespace' => 'pdfresource',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae36c14334f33072fb962b7224e4fb3b',
      'native_key' => 'pdfresource.creator',
      'filename' => 'modSystemSetting/0a3059db49f7a7880809287d9b4ada37.vehicle',
      'namespace' => 'pdfresource',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2a8dd6e4410a37fbd3e486fd2f5e3af',
      'native_key' => 'pdfresource.pdfTv',
      'filename' => 'modSystemSetting/7f9cf7537d68dbe39227456237f11a6a.vehicle',
      'namespace' => 'pdfresource',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9171b0a988d5074ba44b120a5be01f8f',
      'native_key' => 'pdfresource.pdfTvLive',
      'filename' => 'modSystemSetting/16e5f73a00c8972fa2859a1e41c96050.vehicle',
      'namespace' => 'pdfresource',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67fe9600667a61d739ecd5492c519718',
      'native_key' => 'pdfresource.pdfTvOptions',
      'filename' => 'modSystemSetting/2570cd9c7ef4cd909e41bdae504599f7.vehicle',
      'namespace' => 'pdfresource',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81c598a02b4da36169198d4bc2636aba',
      'native_key' => 'pdfresource.pdfTpl',
      'filename' => 'modSystemSetting/5f0321e9005d52e9fd69e39b9bfeb477.vehicle',
      'namespace' => 'pdfresource',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '602813dda49e75cf3c4d281541faee15',
      'native_key' => 'pdfresource.cssTpl',
      'filename' => 'modSystemSetting/684e068a0ee380246fd59d3e6d034e9d.vehicle',
      'namespace' => 'pdfresource',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7304be770f5d34792fa9eb8c0aed829',
      'native_key' => 'pdfresource.headerTpl',
      'filename' => 'modSystemSetting/e11875c0f3982ca7f9d69009e3a1b031.vehicle',
      'namespace' => 'pdfresource',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83e63b0bb0d42cda79d3ef012e670eb2',
      'native_key' => 'pdfresource.footerTpl',
      'filename' => 'modSystemSetting/c553ff719648919f332b106a0d2eacbb.vehicle',
      'namespace' => 'pdfresource',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e900be010c228055827f722dbc4c50b',
      'native_key' => 'pdfresource.processTVs',
      'filename' => 'modSystemSetting/d1c4295d4024fba7e590034ed1dc707d.vehicle',
      'namespace' => 'pdfresource',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86b52c38758364926d7f76640415da3f',
      'native_key' => 'pdfresource.tvPrefix',
      'filename' => 'modSystemSetting/3b834aa098fc27e87bb919ce37216776.vehicle',
      'namespace' => 'pdfresource',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1322634ab04b35f69d7703cffda8f15e',
      'native_key' => NULL,
      'filename' => 'modCategory/99c2c6ae699001c9e058281c029957d2.vehicle',
      'namespace' => 'pdfresource',
    ),
  ),
);